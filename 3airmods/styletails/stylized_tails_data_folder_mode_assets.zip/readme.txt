How to replace data folder assets

1. Put the game into data folder mode. Look up a tutorial on how to set that up as it's too long for me to go into detail here.
2. Replace the files in the original assets with the ones included that share file names. I recommend you back up your original assets so they aren't forever replaced.
3. You're done. Have fun with seeing Stylized Tails in the menus.