THIS MOD IS ONLY TO BE HOSTED ON LUNARFLUORITE. YOU CANNOT MODIFY
AND/OR REDISTRIBUTE THIS MOD WITHOUT OUR EXPLICIT PERMISSION.

PLEASE NOTE THAT THIS MOD WILL ONLY WORK ON 3 AIR VERSION 22.09.10.0 OR ABOVE.
IF YOU DO NOT HAVE THIS VERSION YOU MAY DOWNLOAD IT HERE:
https://github.com/Eukaryot/sonic3air/tags

==IMPORTANT NOTICE==
A lot of stuff was changed up internally, such as sprite sheets and jsons being split up so please delete the SHC build folder before
extracting this version. Thank you!!

==POST-SHC UPDATE CHANGELOG==
-Compatibility stuff
	-Added compatibility with the AIZ demo of Sonic 3 Encore.
		-As Encore gets updated, I will also update Stone to make sure it everything works properly.
-AIZ Miniboss
	-Background ships in the fire transition have been replaced with unique sprites
	-Fixed a bug where the Harder AI would always be used when playing as Knuckles regardless of option
	-Fixed a bug in the fire transition cutscene where Tails could possible end up staring into space for infinity
-HCZ Miniboss
	-Fixed a rare bug with the Harder AI where the water can rise during defeat.
	-Sprites have been updated to add a secondary color to it.
	-Shaker now has new sprites to reflect Stone's color scheme
-CNZ Miniboss
	-Sprites have been updated to add more detail to it.
	-Drill now plays an unused sound when bouncing off a wall
	-Harder AI has been updated greatly for the miniboss. Have fun! :]
-ICZ Miniboss
	-The ship now moves around in a different pattern with Harder AI enabled.
	-Fixed a very minor palette bug with the swinging ice chain.
-LBZ Knux Miniboss
	-Some tweaks to improve the pacing + some other tweaks to make it look a bit fancier.
	-New sprites for the miniboss. Now it's no longer a MGZ and ICZ mishmash!
	-Knuckles now uses some sprites from the HPZ emerald theft cutscene after getting knocked back in the intro. (Works with modded sprites!)
	-Tails gets knocked off the platform in the intro if playing as Knuckles & Tails and doesn't respawn during the fight,
		as his flight assist gets in the way of the actual fight.
	-The boss now emits electricity and glows red when invulnerable.
	-Intro cutscene can now be fast forwarded like other cutscenes.
	-Fixed a bug where the camera had a chance of messing up after defeating the boss in D.A. Garden Edition.
	
-Misc/Other tweaks
	-Fixed a base game bug where boss music plays too early in AIZ and HCZ due to boss encounter value being set to 1 too early.
	-Sonic 1/Pixy palette has been added. Based on one of the original posts that led to this mod's existence!
	-Robbiebotnik palette has been added, the Doctor's assistant can now be number one.
	-The ship colors of the Robo Red palette have been altered to better match Robotnik's S3K ship colors and make the palette more unique.
	-The ship colors of the Movie palette have also been altered to better match Robotnik's machinery in the movies.
	-Inconsistent colors between sprites have been corrected. (ship seat, HCZ miniboss, ICZ miniboss, etc...)
	-Some sprites have been updated to look a bit nicer with alternate palettes (AIZ miniboss, MGZ miniboss)
	-Hoshi miniboss music has been replaced with an Alternate Mix of the S&K Miniboss music.

==INSTALLATION==
Installation of mods in Sonic 3 A.I.R. varies depending on what system you're using to run it.
Please refer to the game manual on page 22 under the section "Installation of Mods" for installation instructions for your system.
You access the manual in-game under the options menu.

==Mods that are compatible/tested with Stone 3 A.I.R.==

-Sonic 3: D.A. Garden Edition (https://gamebanana.com/mods/151029)
-Sonic 3 Encore version 0.36_aiz (https://gamebanana.com/wips/51390)
-Blue Glasses Eggman (https://gamebanana.com/mods/54283)
-Misc. Fixes and Tweaks (https://gamebanana.com/mods/54130)
-Minor S3 Fixes (for LBZ Fleeing Eggman) (https://gamebanana.com/mods/54116)
-Origins AIZ Intros (https://gamebanana.com/mods/408330)
-Extra Slot Mighty (https://gamebanana.com/mods/336038)
-Extra Slot Ray (https://gamebanana.com/mods/403766)
-Super Mario in Sonic 3 AIR (insert mod link here)
-Ultimate Metal Sonic (https://gamebanana.com/mods/330930)
-Extra Life (https://gamebanana.com/mods/321144)

Be sure Stone 3 A.I.R. has higher priority over these mods + any other mods you think could conflict with it!
(Also let me know if there's any mods that cause bugs with it enabled!)

==MOD OPTIONS==
-Palette - The palette Agent Stone + his machinery will use
	-Classic Blue - The default color scheme for the mod
	-Robo Red - Uses colors similar to Robotnik + his ship
	-Movie - Uses colors similar to his outfit from the movie + Robotnik's movie ship colors
	-Sonic 1/Pixy - Uses colors from the S1 palette/Pixy's original palette
	-Robbiebotnik - Don't touch that!
	-Thanks Hesse - why he ourple (https://twitter.com/tyson_hesse/status/1584989254887026688?s=20&t=xcgpTeM9Qxf1jVli0-rbZw)
-Harder AI - A toggle for harder miniboss AI that S3K uses for Knuckles + newly added harder AI for the minibosses that didn't have harder AI before.
-Better Pacing - Removes some movement delay from certain bosses to better improve the pacing of the fight.
-Miniboss Music - The music that plays during every miniboss encounter with Stone
	-Use Default
	-Unique
	-Sonic 3D Blast (Genesis)
	-Sonic 3D Blast (Saturn)


==EASTER EGGS==
There are currently 3 easter eggs in the mod, and more will be added over time. Easter eggs range from simple sound changes to things
that could involve the player dying (but also being rewarded a life at the same time). When enabled, they have a small chance of
occurring. If you do not want to encounter these, they are disabled by default and must be turned on in settings if you want to
come across them randomly.

==KNOWN BUGS/ISSUES THAT I CANNOT FIX==
-Stone not replacing Egg Robo on the continue screen.
	-Stone cannot replace Egg Robo on the continue screen as for some reason I cannot get his palette to load on there at all.
	To my knowledge, this is a base 3 A.I.R. bug. Once this is fixed I will add him there.
-Knux LBZ2 post-boss Cutscene explosion flash bug
	-If 3 A.I.R.'s renderer is not set to OpenGL Hardware, the explosion flash in Knux's LBZ2 post-boss cutscene
	will not render properly. The flash is set to scale to the screen's width and height however the scaling is
	completely broken if the renderer is not set to OpenGL Hardware. This is also a base 3 A.I.R. bug. Thankfully,
	this can easily be fixed by setting the renderer to OpenGL Hardware in Options -> Display.


==FUTURE PLANS FOR THE MOD==
-Finishing up the S&K half of the minibosses
-Integrating Stone into some of the cutscenes
-Even more palettes
-More custom bosses
	

==MAIN CREDITS==
HazelSpooder - Scripting, Sprites, Testing
rosy-eclairs - Sprites, Music, Box Art, Testing
panoramhusky - Sprites, Sonic Jam Bio, Testing
Heatto - Sprites
LunarCryptik - Unique Boss Music
Pixy-pie - Classic Agent Stone design used in the mod (@pics_pixels on Twitter)
Lanthart - Original Classic Agent Stone Design (@Lanth_art on Twitter)
dreamywolf - Agent Stone Artwork, Original Classic Agent Stone Design (@dreamywolfdd on Twitter)
Lave SIime - Palette Assistance
Dynamic Lemons - Rendering Assistance
iCloudius - Ensuring compatibility with Extra Slot Mighty & Ray
Sms8Powa - MGZ2 Boss zoomout animation code from Blue Glasses Eggman
Bastian95 - MacOS Testing
Louplayer - Misc Ship Sprites
TCMusic - Trailer Music
rlan2/Ryan Langley - Mod idea
Lee Majdoub - Bringing the character of Agent Stone to life

==MISC ASSET CREDITS==
Electricity sprites - Sonic the Hedgehog
Genesis Boss Music - Sonic 3D Blast (Genesis)
Saturn Boss Music - Sonic 3D Blast (Saturn)
	Original MIDI by Monster Iestyn	